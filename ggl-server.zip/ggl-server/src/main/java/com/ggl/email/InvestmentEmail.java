package com.ggl.email;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ggl.dto.Member;
import com.ggl.mongo.model.PrivateTree;
import com.ggl.mongo.model.Publictree;
import com.ggl.util.PushEmail;

public class InvestmentEmail {

	public static final Logger logger = LoggerFactory.getLogger(InvestmentEmail.class);

	//--------- Closed After 8 Tree Comes ----
	public static void EightComeOneClosedEmail(Member member){
		logger.info("----------------- Inside Public Tree EightComeOneClosedEmail -------------------");
		logger.info("Unit ID ------->"+member.getInvoiceNumber()); 
		logger.info("Email ID ----------->"+member.getEmailID()); 
		String email_closed ="<html><head><style> .panel { border: 1px solid #00a65a;border-radius:0 !important;transition: box-shadow 0.5s; } </style> "
			+ "<style> table, th , td  { width: 40%;border-collapse: collapse;padding: 5px;margin-left:30%; margin-right:30%; } table thead tr{ background-color: #3c8dbc;}</style> "
	 		+ "<style> table tbody tr:nth-child(odd) { background-color: #dbdee0; } table tbody tr:nth-child(even) { background-color: #b3acac; }tbody {text-align: center;}</style></head>"
	 		+ "<body><div class=\"panel panel-default text-center\"> <div style=\"color: #fff !important;background-color: #3c8dbc !important;padding: 10px;font-size: 20px;border-bottom: 1px solid transparent;text-align: center;\"> "
			+ "<label>Public Tree Unit Closed Info</label> </div><div style=\"background-color: #d2d6de !important;padding-left: 35px;\"> <br/>  " 
	 		+ "<label>Congratulation you just finished the Unit from GGL SEED FUND</label> <br/><br/>"
	 		+ "<label style=\"font-size: 16px;font-weight: bold;padding-left: 20px;\"> Unit ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : &nbsp;&nbsp; " + member.getInvoiceNumber() +"</label> <br/> "
	 		+ "<label style=\"font-size: 16px;font-weight: bold;padding-left: 20px;\"> Unit Status &nbsp;&nbsp;&nbsp; :  &nbsp;&nbsp;  CLOSED </label> <br/><br/>"
	 		+ "<label>The disbursement of fund from Public Tree will take 5 working days </label> <br/><br/>"
	 		
	 		+ "<div style=\"text-align: center;\"> Rewards Total </div><br/>"
	 		+ "<table align=\"center\" style=\"border: 1px solid grey\"><thead><tr><th style=\"background-color: #3c8dbc\">Payment Details</th><th style=\"background-color: #3c8dbc\">Fees</th></tr></thead>"
	 		+ "<tbody><tr><td>Unit Rewards</td><td>500SGD</td></tr><tr><td>Deduction</td><td>100SGD</td></tr><tr style=\"font-weight:bold;\"><td>Total Amount</td><td>400SGD</td></tr></tbody></table><br/>"
			+ "<div style=\"text-align: center;margin-left: -80px;\"> *Note : Rate SGD to Rupiah = IDR 10,000/SGD </div><div style=\"text-align: center;\"> Deduction = Re-registration Public Tree Unit </div><br/><br/>"
	 		+ "<label>we got you covered.check out our FAQ or contact our customer service support info@gglway.com</label><br/>"
			+ "<label>Thank you for join with us,have nice a day. </label><br/><br/>"
	 		+ "<p><b>For and on behalf of</b><p>"
			+ "<p><b>Global Gains Limited</b></p>"
	 		+ "<br/>"
			+ "<img src=\"http://35.162.40.190/images/logo.jpg\" >"
	 		+ " </div></div></body></html>";
		
		try {
			logger.info("Calling Email Service -------------");
			PushEmail.sendMail(member.getEmailID(),"GGL MEMBER Unit Closed",email_closed);
			logger.info("Successfully  Email Called Service------------");	
			
		}catch(Exception e) {
			logger.info("Public EightComeOneClosedEmail Exception -->"+e.getMessage());
		}
	}
	
	// After 8 out and 1 gets Saved as new Tree
	public static void temp8OutandOnseSavedPublicTree(Member member,String emailID) {
		
		StringBuffer sb = new StringBuffer();
		int tempAmount=0;
		//	for(Member m: list) {
			sb.append("<h3>  Unit Chain Invoice Number #:"+member.getInvoiceNumber()+"</h3>");
			//m.getInvoiceNumber();
			tempAmount=tempAmount+100;
		//	}
		System.out.println("String --->"+sb);
		String email ="<!DOCTYPE html>\r\n" + 
				"<html lang=\"en\">\r\n" + 
				"<head>  \r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<div class=\"container\">\r\n" + 
				"<div style=\"background-color: #3c8dbc !important; width: 320px; color: white;padding-left: 200px; padding-right: 200px;\">\r\n" + 
				"<h2> Public Tree Invoice Info</h2>\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"<div class=\"container-fluid bg-grey\">\r\n" + 
				"<div class=\"row\"> \r\n" + 
				"<div class=\"col-sm-8\">\r\n" + 
				"<h2>Thank you for buy the Public Unit from GGL Investement:</h2>\r\n" + 
				"<br>	  \r\n" + sb + 
				"Amount Details :  " +tempAmount+"SGD\r\n" + 
				"Note Please make the payment via Wire transfer or Online payment For and on behalf of Global Gains Limited\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"</div>\r\n" + 
				"<footer class=\"container-fluid text-center\">\r\n" + 
				"<a href=\"#myPage\" title=\"To Top\">\r\n" + 
				"<span class=\"glyphicon glyphicon-chevron-up\"></span>\r\n" + 
				"</a>\r\n" + 
				"<p>GGL System Made By <a href=\"https://www.gglway.com\" title=\"Visit gglway.com\">www.gglway.com</a></p>\r\n" + 
				"</footer>\r\n" + 
				"</body>\r\n" + 
				"</html>\r\n" + 
				"";
		try {

			
			logger.info("Calling Email Service -------------");
			PushEmail.sendMail(emailID,"GGL Public Tree | Purchase Order",email);
			logger.info("Successfully  Email Called Service------------");	
			
		logger.info("Successfully Saved data.");
		}catch(Exception e) {
			logger.info("Exception -->"+e.getMessage());
		}
		
		}


	public static void tempPublicTree(ArrayList<Member> list,String emailID) {
		
		StringBuffer sb = new StringBuffer();
		StringBuffer payment = new StringBuffer();
		int tempAmount=0;
		for(Member m: list) {
			sb.append("<h3>  Unit Invoice Number #:"+m.getInvoiceNumber()+"</h3>");
			payment.append("Public Tree - "+m.getInvoiceNumber()+" ");
			tempAmount=tempAmount+100;
		}
		System.out.println("String --->"+sb);
		System.out.println("Table Payment Details --->"+payment);
		String email ="<!DOCTYPE html>\r\n"  
				+ "	<html><head><style> .panel { border-radius:0 !important;transition: box-shadow 0.5s; } </style> \"\r\n" 
				+ "	<style> table { border-collapse: collapse;width: 100%; } th, td {  border: 1px solid black;padding: 8px;text-align: center; }</style>\"\r\n" 
				+ "	<style> table tbody tr:nth-child(odd) { background-color: #dbdee0; } table tbody tr:nth-child(even) { background-color: #b3acac; }tbody {text-align: center;}</style></head>\"\r\n" 
				+ "	<body><div class=\"panel panel-default text-center\"> <div style=\"color: #fff !important;background-color: #3c8dbc !important;padding: 10px;font-size: 20px;border-bottom: 1px solid transparent;text-align: center;\"> \"\r\n" 
				+ "	<label>Public Tree Unit Closed Info</label> </div><div style=\"background-color: #f3efed !important;padding-left: 35px;\"> <br/>  \" \r\n"  
				+ "	<label>Thank you for buy the Public Unit from GGL SEED FUND : </label> <br/><br/>\"\r\n"  
				+ "	<label style=\"padding-left: 20px;\">\" + sb + \"</h3><label> <br/><br/>\"\r\n"  
				+ "	<label>Please make the payment via Wire transfer</label><br/>\"\r\n" 

				+ "	<table> <thead>  <tr>    <th>Name of Bank</th>     <th>Bank Account Holder</th> \"\r\n" 
				+ "	<th>Bank Account Number</th> 	    <th>Swift Code</th>     <th>CHIPS UID Number</th>     <th>Telex Number</th>     <th>Bank Address</th>   </tr>  </thead>  \"\r\n" 
				+ "	<tbody>  <tr style=\"background-color: #f3efed;\"> <td>DBS Bank</td>     <td>Global Gains Limited</td>     <td>003-932398-0</td> 	    <td>DBSSGSG</td>     <td>0346756</td>     <td>RS - 24455</td> <td> 12 Marina Boulevard,Marina Bay Financial Centre,Tower 3, Singapore 018982\"\r\n" 
				+ "	</td> </tr>  </tbody>  </table>\"\r\n" 

				+ "	<p class=MsoNoSpacing style='text-align:justify;text-justify:inter-ideograph'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt'>\"\r\n" 
				+ "	or Bank Account in thru our partner </span></b></p>\"\r\n" 

				+ "	<table style=\"width:100%:border:2px;\"> <thead>  <tr>    <th>Name of Bank</th>     <th>Bank Account Holder</th> \"\r\n"  
				+ "	<th>Bank Account Number</th> 	    <th>Swift Code</th>     <th>CHIPS UID Number</th>     <th>Telex Number</th>     <th>Bank Address</th>   </tr> </thead>\"\r\n" 
				+ "	<tbody><tr  style=\"background-color: #f3efed;\"><td style='text-align: center;'>CIMB NIAGA</td>  <td style='text-align: center;'>Blueprint Nusatara Indonesia</td>     <td style='text-align: center;'>800077326600</td> 	    <td style='text-align: center;'>BNIAIDJA</td>     <td style='text-align: center;'>84711</td>\"\r\n"  
				+ "	<td style='text-align: center;'>60875 - 60877 NAGA HO IA</td>  <td style='text-align: center;'> GrahaNiaga / Niaga Tower Jl. Jend. SudirmanKav. 58, Jakarta 12190</td> </tr></table>\"\r\n"  

				+ "	<br/>\"\r\n" 
				+ "	<div style=\"text-align: center;\"> Payment Total </div><br/>\"\r\n" 
				+ "	<table align=\"center\" style=\"width: 40%;padding: 5px;margin-left:30%; margin-right:30%;\"><thead><tr><th style=\"background-color: #3c8dbc;border: 1px solid grey\">Type of Payment</th><th style=\"background-color: #3c8dbc;border: 1px solid grey\">Fees</th></tr></thead>\"\r\n" 
				+ " <tbody><tr><td>\" + payment + \"</td><td>\" + member.setPayAmt + \" SGD </td></tr><tr style=\"font-weight:bold;\"><td>Total Amount</td><td>\" + tempAmount + \"</td></tr></tbody></table><br/>\"\r\n"  
				+ "	<div style=\"text-align: center;margin-left: -80px;\"> *Note : Kurs SGD to Rupiah = IDR 10,500/SGD </div><br/><br/>\"\r\n" 

				+ "	<label>Please Confirm and upload if you have made payment to http://ggl.neotural.com/memberpaymentupload</label><br/>\"\r\n" 
				+ "	<label>Thank you for join with us,have nice a day. </label><br/><br/>\"\r\n" 
				+ "	<p><b>For and on behalf of</b><p>\"\r\n"  
				+ "	<p><b>Global Gains Limited</b></p>\"\r\n" 
				+ "	<br/>\"\r\n"  
				+ "	<img src=\"http://35.162.40.190/images/logo.jpg\" >\"\r\n"  
				+ "	</div></div></body></html> ";
		try {

			
			logger.info("Calling Email Service -------------");
			PushEmail.sendMail(emailID,"GGL Public Tree | Purchase Order",email);
			logger.info("Successfully  Email Called Service------------");	
			
		logger.info("Successfully Saved data.");
		}catch(Exception e) {
			logger.info("Exception -->"+e.getMessage());
		}
		
		}
	
	// Own Tree
	public static void tempOwnTree(ArrayList<Member> list,String emailID) {
		
		StringBuffer sb = new StringBuffer();
		StringBuffer payment = new StringBuffer();
		int tempAmount=0;
		for(Member m: list) {
			sb.append("<h3> Own Tree Unit Invoice Number #:"+m.getInvoiceNumber()+"</h3>");
			payment.append("Own Tree - "+m.getInvoiceNumber()+" ");
			tempAmount=tempAmount+100;
		}
		System.out.println("Own String --->"+sb);
		System.out.println("Own Table Payment Details --->"+payment);
		String email ="<!DOCTYPE html>\r\n"  
				+ "	<html><head><style> .panel { border-radius:0 !important;transition: box-shadow 0.5s; } </style> \"\r\n" 
				+ "	<style> table { border-collapse: collapse;width: 100%; } th, td {  border: 1px solid black;padding: 8px;text-align: center; }</style>\"\r\n" 
				+ "	<style> table tbody tr:nth-child(odd) { background-color: #dbdee0; } table tbody tr:nth-child(even) { background-color: #b3acac; }tbody {text-align: center;}</style></head>\"\r\n" 
				+ "	<body><div class=\"panel panel-default text-center\"> <div style=\"color: #fff !important;background-color: #3c8dbc !important;padding: 10px;font-size: 20px;border-bottom: 1px solid transparent;text-align: center;\"> \"\r\n" 
				+ "	<label>Own Tree Unit Closed Info</label> </div><div style=\"background-color: #f3efed !important;padding-left: 35px;\"> <br/>  \" \r\n"  
				+ "	<label>Thank you for buy the Own Unit from GGL SEED FUND : </label> <br/><br/>\"\r\n"  
				+ "	<label style=\"padding-left: 20px;\">\" + sb + \"</h3><label> <br/><br/>\"\r\n"  
				+ "	<label>Please make the payment via Wire transfer</label><br/>\"\r\n" 

				+ "	<table> <thead>  <tr>    <th>Name of Bank</th>     <th>Bank Account Holder</th> \"\r\n" 
				+ "	<th>Bank Account Number</th> 	    <th>Swift Code</th>     <th>CHIPS UID Number</th>     <th>Telex Number</th>     <th>Bank Address</th>   </tr>  </thead>  \"\r\n" 
				+ "	<tbody>  <tr style=\"background-color: #f3efed;\"> <td>DBS Bank</td>     <td>Global Gains Limited</td>     <td>003-932398-0</td> 	    <td>DBSSGSG</td>     <td>0346756</td>     <td>RS - 24455</td> <td> 12 Marina Boulevard,Marina Bay Financial Centre,Tower 3, Singapore 018982\"\r\n" 
				+ "	</td> </tr>  </tbody>  </table>\"\r\n" 

				+ "	<p class=MsoNoSpacing style='text-align:justify;text-justify:inter-ideograph'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt'>\"\r\n" 
				+ "	or Bank Account in thru our partner </span></b></p>\"\r\n" 

				+ "	<table style=\"width:100%:border:2px;\"> <thead>  <tr>    <th>Name of Bank</th>     <th>Bank Account Holder</th> \"\r\n"  
				+ "	<th>Bank Account Number</th> 	    <th>Swift Code</th>     <th>CHIPS UID Number</th>     <th>Telex Number</th>     <th>Bank Address</th>   </tr> </thead>\"\r\n" 
				+ "	<tbody><tr  style=\"background-color: #f3efed;\"><td style='text-align: center;'>CIMB NIAGA</td>  <td style='text-align: center;'>Blueprint Nusatara Indonesia</td>     <td style='text-align: center;'>800077326600</td> 	    <td style='text-align: center;'>BNIAIDJA</td>     <td style='text-align: center;'>84711</td>\"\r\n"  
				+ "	<td style='text-align: center;'>60875 - 60877 NAGA HO IA</td>  <td style='text-align: center;'> GrahaNiaga / Niaga Tower Jl. Jend. SudirmanKav. 58, Jakarta 12190</td> </tr></table>\"\r\n"  

				+ "	<br/>\"\r\n" 
				+ "	<div style=\"text-align: center;\"> Payment Total </div><br/>\"\r\n" 
				+ "	<table align=\"center\" style=\"width: 40%;padding: 5px;margin-left:30%; margin-right:30%;\"><thead><tr><th style=\"background-color: #3c8dbc;border: 1px solid grey\">Type of Payment</th><th style=\"background-color: #3c8dbc;border: 1px solid grey\">Fees</th></tr></thead>\"\r\n" 
				+ " <tbody><tr><td>\" + payment + \"</td><td>\" + member.setPayAmt + \" SGD </td></tr><tr style=\"font-weight:bold;\"><td>Total Amount</td><td>\" + tempAmount + \"</td></tr></tbody></table><br/>\"\r\n"  
				+ "	<div style=\"text-align: center;margin-left: -80px;\"> *Note : Kurs SGD to Rupiah = IDR 10,500/SGD </div><br/><br/>\"\r\n" 

				+ "	<label>Please Confirm and upload if you have made payment to http://ggl.neotural.com/memberpaymentupload</label><br/>\"\r\n" 
				+ "	<label>Thank you for join with us,have nice a day. </label><br/><br/>\"\r\n" 
				+ "	<p><b>For and on behalf of</b><p>\"\r\n"  
				+ "	<p><b>Global Gains Limited</b></p>\"\r\n" 
				+ "	<br/>\"\r\n"  
				+ "	<img src=\"http://35.162.40.190/images/logo.jpg\" >\"\r\n"  
				+ "	</div></div></body></html> ";
		try {

			
			logger.info("Calling Email Service -------------");
			PushEmail.sendMail(emailID,"GGL Own Tree | Purchase Order",email);
			logger.info("Successfully  Email Called Service------------");	
			
		logger.info("Successfully Saved data.");
		}catch(Exception e) {
			logger.info("Exception -->"+e.getMessage());
		}
		
		}
	
	
	// Private Tree
	
		public static void tempPrivateTree(ArrayList<Member> list,String emailID) {
			
			StringBuffer sb = new StringBuffer();
			StringBuffer payment = new StringBuffer();
			int tempAmount=0;
			for(Member m: list) {
				sb.append("<h3>  Unit Invoice Number #:"+m.getInvoiceNumber()+"</h3>");
				payment.append("Private Tree - "+m.getInvoiceNumber()+" ");
				tempAmount=tempAmount+100;
			}
			System.out.println("Private String --->"+sb);
			System.out.println("Private Table Payment Details --->"+payment);
			String email ="<!DOCTYPE html>\r\n"  
					+ "	<html><head><style> .panel { border-radius:0 !important;transition: box-shadow 0.5s; } </style> \"\r\n" 
					+ "	<style> table { border-collapse: collapse;width: 100%; } th, td {  border: 1px solid black;padding: 8px;text-align: center; }</style>\"\r\n" 
					+ "	<style> table tbody tr:nth-child(odd) { background-color: #dbdee0; } table tbody tr:nth-child(even) { background-color: #b3acac; }tbody {text-align: center;}</style></head>\"\r\n" 
					+ "	<body><div class=\"panel panel-default text-center\"> <div style=\"color: #fff !important;background-color: #3c8dbc !important;padding: 10px;font-size: 20px;border-bottom: 1px solid transparent;text-align: center;\"> \"\r\n" 
					+ "	<label>Private Tree Unit Closed Info</label> </div><div style=\"background-color: #f3efed !important;padding-left: 35px;\"> <br/>  \" \r\n"  
					+ "	<label>Thank you for buy the Private Unit from GGL SEED FUND : </label> <br/><br/>\"\r\n"  
					+ "	<label style=\"padding-left: 20px;\">\" + sb + \"</h3><label> <br/><br/>\"\r\n"  
					+ "	<label>Please make the payment via Wire transfer</label><br/>\"\r\n" 

					+ "	<table> <thead>  <tr>    <th>Name of Bank</th>     <th>Bank Account Holder</th> \"\r\n" 
					+ "	<th>Bank Account Number</th> 	    <th>Swift Code</th>     <th>CHIPS UID Number</th>     <th>Telex Number</th>     <th>Bank Address</th>   </tr>  </thead>  \"\r\n" 
					+ "	<tbody>  <tr style=\"background-color: #f3efed;\"> <td>DBS Bank</td>     <td>Global Gains Limited</td>     <td>003-932398-0</td> 	    <td>DBSSGSG</td>     <td>0346756</td>     <td>RS - 24455</td> <td> 12 Marina Boulevard,Marina Bay Financial Centre,Tower 3, Singapore 018982\"\r\n" 
					+ "	</td> </tr>  </tbody>  </table>\"\r\n" 

					+ "	<p class=MsoNoSpacing style='text-align:justify;text-justify:inter-ideograph'><b style='mso-bidi-font-weight:normal'><span style='font-size:12.0pt'>\"\r\n" 
					+ "	or Bank Account in thru our partner </span></b></p>\"\r\n" 

					+ "	<table style=\"width:100%:border:2px;\"> <thead>  <tr>    <th>Name of Bank</th>     <th>Bank Account Holder</th> \"\r\n"  
					+ "	<th>Bank Account Number</th> 	    <th>Swift Code</th>     <th>CHIPS UID Number</th>     <th>Telex Number</th>     <th>Bank Address</th>   </tr> </thead>\"\r\n" 
					+ "	<tbody><tr  style=\"background-color: #f3efed;\"><td style='text-align: center;'>CIMB NIAGA</td>  <td style='text-align: center;'>Blueprint Nusatara Indonesia</td>     <td style='text-align: center;'>800077326600</td> 	    <td style='text-align: center;'>BNIAIDJA</td>     <td style='text-align: center;'>84711</td>\"\r\n"  
					+ "	<td style='text-align: center;'>60875 - 60877 NAGA HO IA</td>  <td style='text-align: center;'> GrahaNiaga / Niaga Tower Jl. Jend. SudirmanKav. 58, Jakarta 12190</td> </tr></table>\"\r\n"  

					+ "	<br/>\"\r\n" 
					+ "	<div style=\"text-align: center;\"> Payment Total </div><br/>\"\r\n" 
					+ "	<table align=\"center\" style=\"width: 40%;padding: 5px;margin-left:30%; margin-right:30%;\"><thead><tr><th style=\"background-color: #3c8dbc;border: 1px solid grey\">Type of Payment</th><th style=\"background-color: #3c8dbc;border: 1px solid grey\">Fees</th></tr></thead>\"\r\n" 
					+ " <tbody><tr><td>\" + payment + \"</td><td>\" + member.setPayAmt + \" SGD </td></tr><tr style=\"font-weight:bold;\"><td>Total Amount</td><td>\" + tempAmount + \"</td></tr></tbody></table><br/>\"\r\n"  
					+ "	<div style=\"text-align: center;margin-left: -80px;\"> *Note : Kurs SGD to Rupiah = IDR 10,500/SGD </div><br/><br/>\"\r\n" 

					+ "	<label>Please Confirm and upload if you have made payment to http://ggl.neotural.com/memberpaymentupload</label><br/>\"\r\n" 
					+ "	<label>Thank you for join with us,have nice a day. </label><br/><br/>\"\r\n" 
					+ "	<p><b>For and on behalf of</b><p>\"\r\n"  
					+ "	<p><b>Global Gains Limited</b></p>\"\r\n" 
					+ "	<br/>\"\r\n"  
					+ "	<img src=\"http://35.162.40.190/images/logo.jpg\" >\"\r\n"  
					+ "	</div></div></body></html> ";
			try {

				
				logger.info("Calling Email Service -------------");
				PushEmail.sendMail(emailID,"GGL Private Tree | Purchase Order",email);
				logger.info("Successfully  Email Called Service------------");	
				
			logger.info("Successfully Saved data.");
			}catch(Exception e) {
				logger.info("Exception -->"+e.getMessage());
			}
			
			}
		
		
		// Private
		
	public static void approvePrivateTree(PrivateTree l ,String emailID) {
			
			StringBuffer sb = new StringBuffer();
			int tempAmount=100;
			//for(Member m: list) {
				sb.append("<h3>  Private Unit Original Invoice Number #:"+l.getInvoiceNumber()+"</h3>");
				//m.getInvoiceNumber();
				//tempAmount=tempAmount+100;
			//}
			//System.out.println("String --->"+sb);
			String email ="<!DOCTYPE html>\r\n" + 
					"<html lang=\"en\">\r\n" + 
					"<head>  \r\n" + 
					"</head>\r\n" + 
					"<body>\r\n" + 
					"<div class=\"container\">\r\n" + 
					"<div style=\"background-color: #3c8dbc !important; width: 320px; color: white;padding-left: 200px; padding-right: 200px;\">\r\n" + 
					"<h2> Private Tree Invoice Info</h2>\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"<div class=\"container-fluid bg-grey\">\r\n" + 
					"<div class=\"row\"> \r\n" + 
					"<div class=\"col-sm-8\">\r\n" + 
					"<h2>Thank you for buy the Private Unit from GGL Investement:</h2>\r\n" + 
					"<br>	  \r\n" + sb + 
					"Paid Amount Details :  " +tempAmount+"SGD\r\n" + 
					"Note Please trak and check in My status in Your Member Login in GGL System behalf of Global Gains Limited\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"<footer class=\"container-fluid text-center\">\r\n" + 
					"<a href=\"#myPage\" title=\"To Top\">\r\n" + 
					"<span class=\"glyphicon glyphicon-chevron-up\"></span>\r\n" + 
					"</a>\r\n" + 
					"<p>GGL System Made By <a href=\"https://www.gglway.com\" title=\"Visit gglway.com\">www.gglway.com</a></p>\r\n" + 
					"</footer>\r\n" + 
					"</body>\r\n" + 
					"</html>\r\n" + 
					"";
			try {

				
				logger.info("Calling Email Service -------------");
				PushEmail.sendMail(emailID,"GGL Private Tree | Purchase Order Confirmed Invoice",email);
				logger.info("Successfully  Email Called Service------------");	
				
			logger.info("Successfully Saved data.");
			}catch(Exception e) {
				logger.info("Exception -->"+e.getMessage());
			}
			
			}
		
		// Own Tree
public static void approveOwnTree(ArrayList<Member> list,String emailID,String owntreeName) {
			
			StringBuffer sb = new StringBuffer();
			int tempAmount=0;
			for(Member m: list) {
				sb.append("<h3> Own Tree Unit Original Invoice Number #:"+m.getInvoiceNumber()+"</h3>");
				//m.getInvoiceNumber();
				tempAmount=tempAmount+100;
			}
			System.out.println("String --->"+sb);
			String email ="<!DOCTYPE html>\r\n" + 
					"<html lang=\"en\">\r\n" + 
					"<head>  \r\n" + 
					"</head>\r\n" + 
					"<body>\r\n" + 
					"<div class=\"container\">\r\n" + 
					"<div style=\"background-color: #3c8dbc !important; width: 320px; color: white;padding-left: 200px; padding-right: 200px;\">\r\n" + 
					"<h2> Own Tree Invoice Info</h2>\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"<div class=\"container-fluid bg-grey\">\r\n" + 
					"<div class=\"row\"> \r\n" + 
					"<div class=\"col-sm-8\">\r\n" + 
					"<h2>Your OWN Tree Name : "+owntreeName+"</h2>\r\n" + 
					"<h2>Thank you for buy the Own Tree Unit from GGL Investement:</h2>\r\n" + 
					"<br>	  \r\n" + sb + 
					"Paid Amount Details :  " +tempAmount+"SGD\r\n" + 
					"Note Please make note Please check the status of your Unit details on behalf of Global Gains Limited\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"<footer class=\"container-fluid text-center\">\r\n" + 
					"<a href=\"#myPage\" title=\"To Top\">\r\n" + 
					"<span class=\"glyphicon glyphicon-chevron-up\"></span>\r\n" + 
					"</a>\r\n" + 
					"<p>GGL System Made By <a href=\"https://www.gglway.com\" title=\"Visit gglway.com\">www.gglway.com</a></p>\r\n" + 
					"</footer>\r\n" + 
					"</body>\r\n" + 
					"</html>\r\n" + 
					"";
			try {

				
				logger.info("Calling Email Service -------------");
				PushEmail.sendMail(emailID,"GGL Own Tree | Purchase Order Confirmed Invoice",email);
				logger.info("Successfully  Email Called Service------------");	
				
			logger.info("Successfully Saved data.");
			}catch(Exception e) {
				logger.info("Exception -->"+e.getMessage());
			}
			
			}
		

// Approved Public Tree 
		
		public static void approvePublicTree( Publictree l ,String emailID) {
			
			StringBuffer sb = new StringBuffer();
			int tempAmount=100;
			//for(Member m: list) {
				sb.append("<h3>  Public Unit Original Invoice Number #:"+l.getInvoiceNumber()+"</h3>");
				//m.getInvoiceNumber();
				//tempAmount=tempAmount+100;
			//}
			//System.out.println("String --->"+sb);
			String email ="<!DOCTYPE html>\r\n" + 
					"<html lang=\"en\">\r\n" + 
					"<head>  \r\n" + 
					"</head>\r\n" + 
					"<body>\r\n" + 
					"<div class=\"container\">\r\n" + 
					"<div style=\"background-color: #3c8dbc !important; width: 320px; color: white;padding-left: 200px; padding-right: 200px;\">\r\n" + 
					"<h2> Public Tree Invoice Info</h2>\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"<div class=\"container-fluid bg-grey\">\r\n" + 
					"<div class=\"row\"> \r\n" + 
					"<div class=\"col-sm-8\">\r\n" + 
					"<h2>Thank you for buy the Private Unit from GGL Investement:</h2>\r\n" + 
					"<br>	  \r\n" + sb + 
					"Paid Amount Details :  " +tempAmount+"SGD\r\n" + 
					"Note Please check the status in Your Member Login in GGL System behalf of Global Gains Limited\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"</div>\r\n" + 
					"<footer class=\"container-fluid text-center\">\r\n" + 
					"<a href=\"#myPage\" title=\"To Top\">\r\n" + 
					"<span class=\"glyphicon glyphicon-chevron-up\"></span>\r\n" + 
					"</a>\r\n" + 
					"<p>GGL System Made By <a href=\"https://www.gglway.com\" title=\"Visit gglway.com\">www.gglway.com</a></p>\r\n" + 
					"</footer>\r\n" + 
					"</body>\r\n" + 
					"</html>\r\n" + 
					"";
			try {

				
				logger.info("Calling Email Service -------------");
				PushEmail.sendMail(emailID,"GGL Public Tree | Purchase Order Confirmed Invoice",email);
				logger.info("Successfully  Email Called Service------------");	
				
			logger.info("Successfully Saved data.");
			}catch(Exception e) {
				logger.info("Exception -->"+e.getMessage());
			}
			
			}
		
		
}
