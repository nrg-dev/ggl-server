package com.ggl.dto;

import java.io.Serializable;

public class EmployerDto extends JobSeekerDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3962716785378801138L;
	
	
	
	/*
	String name;
	String phoneNumber;
	String emailID;
	String country;
	int Id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	
	

*/}
