package com.ggl.util;

public class Test {

	public static void main(String args[]) {
		String name = "John Stanley";
		String[] split = name.split(" ");
		
		System.out.println("Fist Value ----:"+split[0]);
		System.out.println("Second value--->"+split[1]);
	}
}
