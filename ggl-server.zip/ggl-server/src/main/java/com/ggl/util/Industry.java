package com.ggl.util;

public enum Industry {

	CivilEngineering, SoftwareDevelopment, Others; 
}
